def say_hello():
    print("hello world")
